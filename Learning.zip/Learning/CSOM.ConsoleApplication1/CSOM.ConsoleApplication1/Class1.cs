﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSOM.ConsoleApplication1
{
   public class Class1
    {
        static void Main1(string[] args)
        {

            int[] someValues={1,10,20,8};
            
           int count= someValues.Count(i => i > 8);
           Console.Write(count);


            //            Consider this example:

            // string person = people.Find(person => person.Contains("Joe"));
            //versus

            // public string FindPerson(string nameContains, List<string> persons)
            // {
            //     foreach (string person in persons)
            //         if (person.Contains(nameContains))
            //             return person;
            //     return null;
            // }
        }
    }
}
