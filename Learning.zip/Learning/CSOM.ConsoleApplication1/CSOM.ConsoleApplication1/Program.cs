﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SP = Microsoft.SharePoint.Client;
namespace CSOM.ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            DeleteItems();
            Console.WriteLine("Done");
            Console.Read();
            //using (ClientContext clientContext = new ClientContext("https://collab.sfcollabtest.org/sites/wss0000r2"))
            //{

            //    Web web = clientContext.Web;
            //    ListCollection collList = web.Lists;
            //   // clientContext.Load(collList, lists => lists.Where(list => list.Hidden == false));
            //    //clientContext.Load(collList, lists => lists.Where(list => (list.Hidden == true)));

            //    clientContext.Load(collList, lists => lists.Where(list => list.Hidden == true).Include(list => list.Title));

            //    //clientContext.LoadQuery(web.Lists.Include(list => list.Title));

            //    clientContext.ExecuteQuery();

            //   // clientContext.Load(web, web1 => web1.Title, web1 => web1.Description);

            //    foreach (var item in collList)
            //    {
                    
            //    }
            //}
        }


        static void DeleteItems()
        {
            using (ClientContext clientContext = new ClientContext("https://collab.sfcollabtest.org/sites/wss0000r2"))
            {
                List list = clientContext.Web.Lists.GetByTitle("CreativeBriefs");
                
                CamlQuery query = CamlQuery.CreateAllItemsQuery(100); 
               ListItemCollection collItems = list.GetItems(query);
               clientContext.Load(collItems,
                   eachItem => eachItem.Include(item => item, item => item["Id"])
                   );
               clientContext.ExecuteQuery();

               var itemCount = collItems.Count;
               for (int i = itemCount; i > 0; i--)
               {
                   collItems[i-1].DeleteObject();

               }
               clientContext.ExecuteQuery();
               //foreach (var item in itemCount)
               //{
                   
               //}

            }
        }
    }
}
